#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdbool.h>

// Function declarations
int findAtPosition(const char* email); // Find '@' in the string
int checkLength(const char* email);
int atCounter(const char* email);
int checkStartEnd(const char* email);
int validatingCharacters(const char* email);
int checkingDoubles(const char* email);


// ------------------------- Validation functions ------------------------- //
int validatingCharacters(const char* email) {  // Verify that all characters are valid
	int i = 0;
	int length = strlen(email);

	for (i = 0; i < length; i++)
	{
		// If there are empty spaces, show message and return error
		if (email[i] == ' ') {
			printf("The email address should not contain empty spaces\n");
			return 1;
		}

		// Valid characters: letters, numbers, ., -, _, +, @, .
		if (isalpha(email[i]) || isdigit(email[i]) || email[i] == '.' || email[i] == '-' || email[i] == '_' || email[i] == '+' || email[i] == '@')
		{
			;// do nothing if good, keep testing in the affirmative
		}
		else
		{
			printf("Bad characters found: %c\n", email[i]);
			return 1;  // Returns error
		}
	}
	return 0;  // All correct
}

int checkingDoubles(const char* email)
{
	int i = 0;
	int length = strlen(email);

	// Check for double characters
	for (int i = 0; i < length - 1; i++) {
		if ((email[i] == '.' && email[i + 1] == '.') ||
			(email[i] == '-' && email[i + 1] == '-') ||
			(email[i] == '_' && email[i + 1] == '_') ||
			(email[i] == '+' && email[i + 1] == '+')) {
			printf("Bad_Double_Characters\n"); // Invalid email
			return 1;
		}
	}
	return 0;

}

int checkStartEnd(const char* email) {
	int length = strlen(email);

	// Check if the first or last character is '.', '-', '_', or '@'
	if (email[0] == '.' || email[0] == '-' || email[0] == '_' || email[0] == '@' ||
		email[length - 1] == '.' || email[length - 1] == '-' ||
		email[length - 1] == '_' || email[length - 1] == '@')
	{
		printf("Bad start or end character found\n"); // Invalid email
		return 1;
	}
	return 0;

}

// Count how many times the '@' character appears in the email
int atCounter(const char* email)
{
	int length = strlen(email);
	int atCounter = 0;

	for (int i = 1; i < length; i++) {  // from i = 1 up to length, because we already checked the borders

		if (email[i] == '@')
		{
			atCounter++;
		}
	}

	if (atCounter != 1)
	{
		printf("The email address should have one '@'\n");
		return 1;
	}
	return 0;

}

// Verify that the total length of the email is less than or equal to 254 characters.
int checkLength(const char* email)
{
	int length = strlen(email);

	if (length > 254)
	{
		printf("The max length of the email address is 254 characters\n");
		return 1;
	}
	return 0;

}

// Verify that the part before the '@' is no longer than 64 characters.
int findAtPosition(const char* email)
{
	int maxLength = 64;
	char* atPosition = strchr(email, '@');
	int nameLength;

	// Calculate the length of the name part before '@'
	nameLength = atPosition - email;


	if (nameLength > maxLength) {
		printf("Invalid Email: The name part before '@' exceeds %d characters\n", maxLength);
		return 1;
	}
	return 0;
}


int main()
{
	char email[1000];   // Enough space for email
	int problemFound;   // Flag to know if an error was found
	
	// Requests the user to enter the email address
	printf("Please enter your email address: ");
	//scanf_s("%999s", email, (unsigned)sizeof(email));

	// Use fgets to allow reading spaces
	if (fgets(email, sizeof(email), stdin)) {
		// Remove newline character if present
		size_t len = strlen(email);
		if (len > 0 && email[len - 1] == '\n') {
			email[len - 1] = '\0';
		}
	}
	

	problemFound = validatingCharacters(email);  // if problem found in any step, none of the remaining steps will be done

	if (problemFound == 0) {
		problemFound = checkingDoubles(email);
	}

	if (problemFound == 0) {
		problemFound = checkStartEnd(email);
	}

	if (problemFound == 0) {
		problemFound = atCounter(email);
	}

	if (problemFound == 0) {
		problemFound = checkLength(email);
	}

	if (problemFound == 0) {
		problemFound = findAtPosition(email);
	}

	// If no error was detected, the email is reported as valid.
	if (problemFound == 0) {
		printf("The email string is valid: %s\n", email);
	}

	return 0;
}
