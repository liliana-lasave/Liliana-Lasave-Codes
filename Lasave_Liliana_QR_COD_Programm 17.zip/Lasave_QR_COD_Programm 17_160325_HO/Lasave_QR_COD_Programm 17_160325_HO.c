#include <stdio.h>
#include <stdlib.h>
#include <time.h>  

/*
* Number guessing game program for exercise 17.
*/

void num_guesses(int secret_number, int range); // Function declaration
int generate_secret_number (int range);

/*
* Funtion to allow user to guess number and print the number of guesses
* it took.  Input parms are the number to guess and the range of 
* numbers that the secret number is in.
*/

void num_guesses (int secret_number, int range) {  // Function definition
	int counter = 0;
	int num_guessed = 0;
	
	while (1) {
		printf ("\nGuess the secret number between 1 and %d: ", range);
		scanf_s("%d", &num_guessed);
		counter++;

		if (num_guessed < secret_number) {
			printf("Wrong number. Try a larger number: \n");

		} else if (num_guessed > secret_number) {
			printf("Wrong number. Try a smaller number: \n");

		} else {
			printf("Congratulations! You guessed the secret number! \n");
			break; // Exit while loop after guessing number
		}
	} 
	printf("Your score was : %d \n", counter);
}

/*
* Get range function that ask the user for the level of difficulty
* and returns the value of the range.
*/

int get_range() {  
	int difficulty;
	int range = 0;

	printf("Enter 1, 2 or 3, for easy, medium or difficult level: ");
	scanf_s("%d", &difficulty);

	switch (difficulty) {

	case 1:
		range = 10;
		break;
	case 2:
		range = 20;
		break;
	case 3:
		range = 30;
		break;
	}
	return range;
}


/*
* Generate secret number randomly generates a secret number.
* The input parm is the maximum number of the range.
* The return parm is the random secret number.
*/

int generate_secret_number(int range) {
	int secret_number;

	secret_number = rand () % (range) + 1;
	
	return secret_number;
}


int main() {
	int range;
	int yes_no;
	int secret_number;

	srand(time(NULL));  // Initialize random seed
	range = get_range();

	while (1) { // Infinite loop

		secret_number = generate_secret_number(range);
		num_guesses(secret_number, range);
		
		printf ("\nDo you want to play again? Choose 1 for yes and 2 for no: ");
		scanf_s ("%d", &yes_no);  
		
		if (yes_no == 2) {
			break;  // This will exit the program when user requests.
		}
	}
		return 0;
}


//Pseudo-Code used in designing the program:
//
//int how_many_guesses
//
//counter = 0
//while (1)
//	guess = read("give number")
//	counter++
//
//	if guess < unknown:
//		print(choose bigger)
//	else if guess > unknown:
//		print(choose smaller
//	else
//		print("congrats")
//		break
//
//
//print "your score was", counter

 //Pseudo-Code for playing again:
 /*
 play again = yes = True
 loop while play again == True

	UserGuessesNumber()
	print (want to play again y/n)
	scan (for y/n)
	if 'n': playAgain = False
 */

/*Pseudo - Code for choosing difficulty level :
function: choosing_level
question: choose 1, 2 or 3
wrong input? 

*/

/*
int getRange ()

	int range;

	print enter 1,2,3 for difficulty:
	scan (difficulty)

	if 1:
		range = 10
	elseif 2:
		range = 20
	else:
		range = 30

	return range

main ():

	range = getRange()

*/